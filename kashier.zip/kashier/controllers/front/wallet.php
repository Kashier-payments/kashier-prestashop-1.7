<?php

use Braintree\Merchant;

class KashierWalletModuleFrontController extends ModuleFrontController
{
	public $ssl = true;
	public $display_column_left = false;

	/**
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
		parent::initContent();
		$cart = $this->context->cart;

		if (!$this->module->checkCurrency($cart))
			Tools::redirect('index.php?controller=order');

		$mode = '';
		if(Configuration::get('TEST_MODE') == 1)
			$mode = 'TEST_API_KEY';
		else
			$mode = 'LIVE_API_KEY';

		$hash = $this->generateKashierOrderHash(array(
			'mid' => Configuration::get('MERCHANT_ID'),
			'amount' => $cart->getOrderTotal(true, Cart::BOTH),
			'currency' => $this->context->currency->iso_code,
			'merchantOrderId' => time(). '-' . $cart->id,
			'secret' => Configuration::get($mode),
		));

		
        /** @var CustomerCore $customer */
        $customer = new Customer($cart->id_customer);

        /**
         * Check if this is a vlaid customer account
         */
        if (!Validate::isLoadedObject($customer)) {
            Tools::redirect('index.php?controller=order&step=1');
        }
 
		
		$metaData = array(
			'order Id' => $cart->id,
			'Customer Email' => $customer->email,
			'Customer Name' => $customer->firstname . ' ' . $customer->lastname,
		);

		$link = $this->context->link->getModuleLink('kashier', 'validation', array(), true);
		
		$linkParts = explode("://", $link);
		$finalLink = urlencode($linkParts[0]."://www.".$linkParts[1]);

		// $baseURL = (Configuration::get('TEST_MODE') == 1)? "https://test-iframe.kashier.io/js/kashier-checkout.js" : "https://iframe.kashier.io/js/kashier-checkout.js" ;
		$baseURL = "https://d1vpaq3sx4yj6p.cloudfront.net/kashier-checkout.js";

		$this->context->smarty->assign(array(
			'nbProducts' => $cart->nbProducts(),
			'cust_currency' => $cart->id_currency,
			'mid' => Configuration::get('MERCHANT_ID'),
			'orderId' => time(). '-' . $cart->id,
			'usrCurrency' => $this->context->currency->iso_code,
			'hash' => $hash,
			'allowedmethods' => 'wallet',
			'mode' => (Configuration::get('TEST_MODE') == 1) ? 'test' : 'live',
			'currencies' => $this->module->getCurrency((int) $cart->id_currency),
			'amount' => $cart->getOrderTotal(true, Cart::BOTH),
			'baseUrl' => $baseURL,
			'redirectURL' => $finalLink,
			'metaData' => json_encode($metaData),
			'store' => Configuration::get('PS_SHOP_NAME'),
			'lang' => ($this->context->language->iso_code == 'ar')? $this->context->language->iso_code : 'en' ,
			'this_path' => $this->module->getPathUri(),
			'this_path_bw' => $this->module->getPathUri(),
			'this_path_ssl' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $this->module->name . '/'
		));

		$this->setTemplate('module:kashier/views/templates/front/payment_execution_wallet.tpl');
	}



	public function generateKashierOrderHash($order)
	{

		$mid = $order['mid']; 

		$amount = $order['amount']; 

		$currency = $order['currency']; 

		$orderId = $order['merchantOrderId'];

		$secret = $order['secret'];

		$path = "/?payment=".$mid.".".$orderId.".".$amount.".".$currency;
		return hash_hmac( 'sha256' , $path , $secret ,false);
	}
}
