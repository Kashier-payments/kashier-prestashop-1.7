<?php

class KashierValidationModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	public function postProcess()
	{
		$cart = $this->context->cart;
		if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
			Tools::redirect('index.php?controller=order&step=1');
		$authorized = false;
		foreach (Module::getPaymentModules() as $module)
			if ($module['name'] == 'kashier') {
				$authorized = true;
				break;
			}
		if (!$authorized)
			die($this->module->l('This payment method is not available.', 'validation'));

		$customer = new Customer($cart->id_customer);
		if (!Validate::isLoadedObject($customer))
			Tools::redirect('index.php?controller=order&step=1');

		$currency = $this->context->currency;
		$total = (float) $cart->getOrderTotal(true, Cart::BOTH);

		// set transaction id in details 
		$extreVars = array(
			'transaction_id' => Tools::getValue('transactionId')
		);

		if (Tools::getValue('paymentStatus') != 'SUCCESS') {
			$this->module->validateOrder($cart->id, (int) Configuration::get('ERROR_STATE'), $total, $this->module->displayName, null, $extreVars, (int) $currency->id, false, $customer->secure_key);			

			$message = $this->module->l('An error occured. Please contact the merchant to have more informations');

			$this->context->smarty->assign(array(
				'message' => $message
			));	

			return $this->setTemplate('module:kashier/views/templates/front/error.tpl');
		}
		
		// create successfull order 
		$this->module->validateOrder($cart->id, Configuration::get('PS_OS_PAYMENT'), $total, $this->module->displayName, NULL, $extreVars, (int) $currency->id, false, $customer->secure_key);
		Tools::redirect('index.php?controller=order-confirmation&id_cart=' . $cart->id . '&id_module=' . $this->module->id . '&id_order=' . $this->module->currentOrder . '&key=' . $customer->secure_key . '&transactionId=' . Tools::getValue('transactionId'));
	}
}
